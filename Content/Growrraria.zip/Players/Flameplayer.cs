using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Microsoft.Xna.Framework.Graphics;
using Terraria.ModLoader;
using Growrarria.Content.Projectiles;

namespace Growrarria.Content.Players
{
    public class FlameEyePlayer : ModPlayer
    {
        public bool hasFlameEye = false;
        private int attackCooldown = 0;

        public int currentEyeFrame = 0;
        private int eyeFrameTimer = 0;

        // Stores the fully-resolved draw position each frame so the draw layer
        // can use it. ModifyDrawInfo is called after Terraria has calculated the
        // walk bob, so drawInfo.Position here is the correct bobbing position.
        public Vector2 cachedDrawPos;
        public Vector2 cachedHeadVect;
        public float   cachedHeadRotation;
        public SpriteEffects cachedPlayerEffect;

        public override void ResetEffects()
        {
            hasFlameEye = false;
        }

        // ModifyDrawInfo is called once per frame right before draw layers run,
        // with the fully-calculated draw position including walk bob baked in.
        // We cache everything the draw layer needs from here.
        public override void ModifyDrawInfo(ref PlayerDrawSet drawInfo)
        {
            cachedDrawPos       = drawInfo.Position;
            cachedHeadVect      = drawInfo.headVect;
            cachedHeadRotation  = drawInfo.drawPlayer.headRotation;
            cachedPlayerEffect  = drawInfo.playerEffect;
        }

        public override void PostUpdateEquips()
        {
            if (hasFlameEye)
            {
                Player.tileRangeX += 3;
                Player.tileRangeY += 3;
                Player.blockRange += 3;
            }
        }

        public override void PostUpdate()
        {
            if (!hasFlameEye)
            {
                currentEyeFrame = 0;
                eyeFrameTimer   = 0;
                return;
            }

            eyeFrameTimer++;
            if (eyeFrameTimer >= 6)
            {
                eyeFrameTimer = 0;
                currentEyeFrame = (currentEyeFrame + 1) % 3;
            }

            if (attackCooldown > 0) attackCooldown--;

            if (Keyboard.GetState().IsKeyDown(Keys.Q) && attackCooldown <= 0 && !Player.dead)
            {
                if (!Main.drawingPlayerChat && !Main.editSign && !Main.editChest)
                {
                    SpawnFlameBreath();
                    attackCooldown = 5;
                }
            }
        }

        private void SpawnFlameBreath()
        {
            Vector2 spawnPos = Player.MountedCenter + new Vector2(6f * Player.direction, -2f);
            Vector2 targetDirection = Main.MouseWorld - spawnPos;
            targetDirection.Normalize();
            Vector2 spreadVelocity = (targetDirection * 8.5f).RotatedBy(Main.rand.NextFloat(-0.12f, 0.12f));

            if (Main.myPlayer == Player.whoAmI)
            {
                Projectile.NewProjectile(
                    Player.GetSource_FromThis(),
                    spawnPos,
                    spreadVelocity,
                    ModContent.ProjectileType<FlameBreath>(),
                    25,
                    1.5f,
                    Player.whoAmI
                );
            }
        }
    }
}