using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using ReLogic.Content;
using Terraria;
using Terraria.DataStructures;
using Terraria.ModLoader;

namespace Growrarria.Content.Players
{
    public class FlameEyeDrawLayer : PlayerDrawLayer
    {
        private Asset<Texture2D> textureAsset;

        public override Position GetDefaultPosition() => new AfterParent(PlayerDrawLayers.FaceAcc);

        public override bool GetDefaultVisibility(PlayerDrawSet drawInfo)
        {
            Player player = drawInfo.drawPlayer;
            if (player.dead || player.invis)
                return false;

            int flameEyeType = ModContent.ItemType<Items.FlameEye>();
            for (int i = 0; i < player.armor.Length; i++)
            {
                if (player.armor[i].type == flameEyeType)
                    return true;
            }
            return false;
        }

        protected override void Draw(ref PlayerDrawSet drawInfo)
        {
            if (drawInfo.shadow != 0f)
                return;

            textureAsset ??= ModContent.Request<Texture2D>("Growrarria/Content/Players/FlameEyeWorn");
            if (textureAsset is not { IsLoaded: true, Value: Texture2D texture })
                return;

            Player player = drawInfo.drawPlayer;
            FlameEyePlayer modPlayer = player.GetModPlayer<FlameEyePlayer>();

            int frameHeight = texture.Height / 3;
            Rectangle sourceRect = new Rectangle(0, modPlayer.currentEyeFrame * frameHeight, texture.Width, frameHeight);

            // Use the position cached in ModifyDrawInfo — this has the walk bob
            // already baked in because ModifyDrawInfo runs after Terraria has
            // calculated the frame-by-frame position offset for the walk cycle.
            Vector2 cachedPos = modPlayer.cachedDrawPos;
            Vector2 headVect  = modPlayer.cachedHeadVect;

            Vector2 position = player.headPosition + headVect + new Vector2(
                (int)(cachedPos.X + player.width / 2f - player.bodyFrame.Width / 2f - Main.screenPosition.X),
                (int)(cachedPos.Y + player.height - player.bodyFrame.Height + 4f - Main.screenPosition.Y)
            );

            drawInfo.DrawDataCache.Add(new DrawData(
                texture,
                position,
                sourceRect,
                Color.White,
                modPlayer.cachedHeadRotation,
                headVect,
                1f,
                modPlayer.cachedPlayerEffect,
                0
            ));
        }
    }
}