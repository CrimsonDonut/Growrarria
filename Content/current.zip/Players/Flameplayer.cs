using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input; // Required for checking the physical 'Q' key
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using Growrarria.Content.Projectiles;

namespace Growrarria.Content.Players
{
    public class FlameEyePlayer : ModPlayer
    {
        public bool hasFlameEye = false;
        
        // Attack throttle to prevent spawning 60 projectiles a second
        private int attackCooldown = 0;

        // --- THE ANIMATION TRACKERS NEEDED BY THE DRAW LAYER ---
        public int currentEyeFrame = 0;
        private int eyeFrameTimer = 0;

        public override void ResetEffects()
        {
            hasFlameEye = false;
        }

        // Applies the +3 reach bonuses when equipped
        public override void PostUpdateEquips()
        {
            if (hasFlameEye)
            {
                Player.tileRangeX += 3;
                Player.tileRangeY += 3;
                Player.blockRange += 3;
            }
        }

        public override void PostUpdate()
        {
            // If the accessory isn't on, reset animation frames and exit early
            if (!hasFlameEye)
            {
                currentEyeFrame = 0;
                eyeFrameTimer = 0;
                return;
            }

            // 1. RUN THE SPRITESHEET ANIMATION ENGINE
            eyeFrameTimer++;
            if (eyeFrameTimer >= 6) // Lower this number to make the eye animation flicker faster
            {
                eyeFrameTimer = 0;
                currentEyeFrame++;
                if (currentEyeFrame >= 3) // Loop back to frame 0 after completing frame 2
                {
                    currentEyeFrame = 0;
                }
            }

            // 2. PROCESS KEYBOARD INPUT FOR HELLFIRE BREATH
            if (attackCooldown > 0) attackCooldown--;

            // Check if the player is pressing 'Q' on their keyboard
            if (Keyboard.GetState().IsKeyDown(Keys.Q) && attackCooldown <= 0 && !Player.dead)
            {
                // Prevent firing while talking to NPCs or using menus
                if (!Main.drawingPlayerChat && !Main.editSign && !Main.editChest)
                {
                    SpawnFlameBreath();
                    attackCooldown = 5; // Fires a flame puff every 5 game ticks
                }
            }
        }

        private void SpawnFlameBreath()
        {
            // Calculate a point starting near the player's face
            Vector2 spawnPos = Player.MountedCenter + new Vector2(6f * Player.direction, -2f);
            
            // Vector calculation pointing from player directly to mouse crosshair
            Vector2 targetDirection = Main.MouseWorld - spawnPos;
            targetDirection.Normalize();
            
            // Base launch speed
            Vector2 launchVelocity = targetDirection * 8.5f;

            // Apply a slight spread so it looks like a realistic organic flame cone
            Vector2 spreadVelocity = launchVelocity.RotatedBy(Main.rand.NextFloat(-0.12f, 0.12f));

            if (Main.myPlayer == Player.whoAmI)
            {
                Projectile.NewProjectile(
                    Player.GetSource_FromThis(),
                    spawnPos,
                    spreadVelocity,
                    ModContent.ProjectileType<FlameBreath>(),
                    25, // Change this number to adjust your base breath damage!
                    1.5f, // Knockback value
                    Player.whoAmI
                );
            }
        }
    }
}