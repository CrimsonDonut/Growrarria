using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.DataStructures;
using Terraria.ModLoader;

namespace Growrarria.Content.Players
{
    public class FlameEyeDrawLayer : PlayerDrawLayer
    {
        public override Position GetDefaultPosition() => new AfterParent(PlayerDrawLayers.FaceAcc);

        public override bool GetDefaultVisibility(PlayerDrawSet drawInfo)
        {
            return drawInfo.drawPlayer.GetModPlayer<FlameEyePlayer>().hasFlameEye
                && !drawInfo.drawPlayer.dead
                && !drawInfo.drawPlayer.invis;
        }

        protected override void Draw(ref PlayerDrawSet drawInfo)
        {
            // Skip shadow passes
            if (drawInfo.shadow != 0f)
                return;

            Player player = drawInfo.drawPlayer;
            FlameEyePlayer modPlayer = player.GetModPlayer<FlameEyePlayer>();

            Texture2D texture = ModContent.Request<Texture2D>("Growrarria/Content/Players/FlameEyeWorn").Value;
            int totalFrames = 3;
            int frameHeight = texture.Height / totalFrames;
            Rectangle sourceRect = new Rectangle(0, modPlayer.currentEyeFrame * frameHeight, texture.Width, frameHeight);

            // Exact formula from the official tModLoader Saethar head glow layer:
            // headPosition carries the walk bob. headVect is the pivot offset.
            // The order must be: headPosition + headVect + basePosition.
            Vector2 position = player.headPosition + drawInfo.headVect + new Vector2(
                (int)(drawInfo.Position.X + player.width / 2f - player.bodyFrame.Width / 2f - Main.screenPosition.X),
                (int)(drawInfo.Position.Y + player.height - player.bodyFrame.Height - Main.screenPosition.Y)
            );

            // Horizontal nudge to sit over the eye area.
            // Positive = toward the front of the face (respects facing direction).
            position.X += 2f * player.direction;
            position.Y -= 8f;

            // Origin: centered X, anchored to top of frame.
            // Top-anchor means the art's position within the frame canvas controls
            // vertical placement — art sitting at y=4 in a 28px frame lands 4px
            // below the top of the head, which is roughly eye height.
            Vector2 origin = new Vector2(texture.Width / 2f, 0f);

            DrawData drawData = new DrawData(
                texture,
                position,
                sourceRect,
                Color.White,
                player.headRotation,
                origin,
                1f,
                drawInfo.playerEffect,
                0
            );

            drawData.shader = player.cFace;
            drawInfo.DrawDataCache.Add(drawData);
        }
    }
}