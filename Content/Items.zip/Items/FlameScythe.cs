using Microsoft.Xna.Framework;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;
using Growrarria.Content.Projectiles;

namespace Growrarria.Content.Items
{
	public class FlameScythe : ModItem
	{
		public override void SetDefaults()
		{
			Item.damage = 120;
			Item.DamageType = DamageClass.Magic;
			Item.mana = 1;

			Item.width = 64;
			Item.height = 56;

			// Low useTime + autoReuse + channel = continuous beam on left click.
			Item.useTime = 15;
			Item.useAnimation = 4;
			Item.useStyle = ItemUseStyleID.Shoot;
			Item.noMelee = true;
			Item.autoReuse = true;
			Item.channel = true;

			Item.knockBack = 4f;
			Item.value = Item.sellPrice(gold: 8);
			Item.rare = ItemRarityID.LightRed;
			Item.UseSound = SoundID.Item43;

			Item.shoot = ModContent.ProjectileType<BlackThunderboltBeam>();
			Item.shootSpeed = 12f;
		}

		public override void PostUpdate()
		{
    	Lighting.AddLight(Item.Center, 1.0f, 0.4f, 0.05f);
		}

		public override bool AltFunctionUse(Player player) => true;

		public override Vector2? HoldoutOffset()
		{
			return new Vector2(-10f, 0f);
		}

		public override bool Shoot(Player player, EntitySource_ItemUse_WithAmmo source, Vector2 position, Vector2 velocity, int type, int damage, float knockback)
		{
			if (player.altFunctionUse == 2)
			{
				// Right click: launch a spinning fire scythe that phases through walls
				// and curves back toward the player (Death Sickle behavior).
				// Spawn it from the player's center and fire it toward the cursor.
				// The sickle AI handles the arc-back automatically.
				Projectile.NewProjectile(
					source,
					player.Center,
					velocity * 1.5f,  // a bit faster than the default shoot speed for a satisfying arc
					ModContent.ProjectileType<FlameScytheProjectile>(),
					damage * 2,       // right-click hits harder as a tradeoff for the longer cooldown
					knockback,
					player.whoAmI
				);
				return false;
			}

			// Left click: continuous beam toward the cursor.
			Projectile.NewProjectile(source, position, velocity, type, damage, knockback, player.whoAmI);
			return false;
		}

		public override void AddRecipes()
		{
			Recipe recipe = CreateRecipe();
			recipe.AddIngredient(ItemID.HellstoneBar, 12);
			recipe.AddIngredient(ItemID.SoulofNight, 6);
			recipe.AddTile(TileID.Anvils);
			recipe.Register();
		}
	}
}