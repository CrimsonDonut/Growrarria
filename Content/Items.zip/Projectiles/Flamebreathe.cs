using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.GameContent;
using Terraria.ID;
using Terraria.ModLoader;

namespace Growrarria.Content.Projectiles
{
    public class FlameBreath : ModProjectile
    {
        // TEXTURE REQUIREMENT: 
        // Ensure you have a blank, transparent square saved as "FlameBreath.png" 
        // in your Growrarria/Content/Projectiles/ folder alongside this script.

        public override void SetDefaults()
        {
            // Exact hitbox dimension used by the player's vanilla flamethrower
            Projectile.width = 16;
            Projectile.height = 16;
            
            // Set to -1 to completely disconnect from vanilla's self-harming trap loops
            Projectile.aiStyle = -1; 

            Projectile.friendly = true;
            Projectile.hostile = false; // Guarantees 100% safety so it never damages you
            Projectile.DamageType = DamageClass.Magic;
            Projectile.penetrate = -1;
            Projectile.timeLeft = 45; // Exact travel lifespan of vanilla flames
            Projectile.tileCollide = true;
            Projectile.ignoreWater = false;

            Projectile.usesLocalNPCImmunity = true;
            Projectile.localNPCHitCooldown = 12;
            
            // Start fully visible so the custom fade calculations control transparency
            Projectile.alpha = 0; 
        }

        public override void AI()
        {
            // Track age moving forward from 0 to 45 ticks
            float age = 45f - Projectile.timeLeft;

            // 1. Initial Launch Speed Tuning
            if (age <= 1f)
            {
                // Replicates the secret vanilla "intermittent clumping" physics:
                // Fast puffs collide with slow puffs in mid-air to form a seamless wall of fire.
                Projectile.velocity *= Main.rand.NextFloat(0.85f, 1.35f);
                Projectile.timeLeft = Main.rand.Next(38, 48);
            }

            // 2. Linear Fluid Deceleration 
            if (age > 3f)
            {
                Projectile.velocity *= 0.965f; 
            }

            // 3. Exact 1:1 Scale Expansion Profile
            Projectile.scale = 0.4f + (age / 45f) * 1.4f;

            // 4. Dynamic Collision Hitbox Adjustment
            int currentSize = (int)(16 * Projectile.scale);
            if (currentSize > 40) currentSize = 40; // Prevent wall clipping issues
            
            Projectile.position = Projectile.Center;
            Projectile.width = currentSize;
            Projectile.height = currentSize;
            Projectile.Center = Projectile.position;

            // 5. Environmental Brightness Glow
            Lighting.AddLight(Projectile.Center, 1.0f, 0.5f, 0.1f);

            // 6. Secondary Native Spark Trailing
            if (Main.rand.NextBool(2))
            {
                int d = Dust.NewDust(
                    Projectile.position, Projectile.width, Projectile.height,
                    DustID.Torch,
                    Projectile.velocity.X * 0.2f, Projectile.velocity.Y * 0.2f,
                    100, default, Projectile.scale * 1.2f);
                Main.dust[d].noGravity = true;
            }
        }

        public override bool PreDraw(ref Color lightColor)
        {
            // Safely fetch the official 7-frame player flamethrower asset sheet
            Texture2D texture = TextureAssets.Projectile[ProjectileID.Flames].Value;
            
            int totalFrames = 7; 
            int frameHeight = texture.Height / totalFrames;
            float age = 45f - Projectile.timeLeft;

            // Track animation frame index matching vanilla lifetime brackets
            int currentFrame = 0;
            if (age >= 30f) currentFrame = 5 + ((int)(age - 30f) / 4) % 2;
            else if (age >= 12f) currentFrame = 3 + ((int)(age - 12f) / 5) % 2;
            else currentFrame = ((int)age / 4) % 3;

            Rectangle sourceRectangle = new Rectangle(0, currentFrame * frameHeight, texture.Width, frameHeight);
            Vector2 drawOrigin = new Vector2(texture.Width / 2f, frameHeight / 2f);
            
            // Align rotation with velocity trajectory vector
            float rotation = Projectile.velocity.LengthSquared() > 0.1f 
                ? Projectile.velocity.ToRotation() + MathHelper.PiOver2 
                : Projectile.rotation + MathHelper.PiOver2;

            // Calculate precise visual fade-out multiplier over the flame's life span
            float opacity = 1f;
            if (age > 25f)
            {
                opacity = 1f - ((age - 25f) / 20f);
                if (opacity < 0f) opacity = 0f;
            }

            // FIX: We draw three layered flame puffs per projectile.
            // This manually generates extreme density and brightness without the risk 
            // of manual spritebatch restarts making the assets disappear.
            for (int i = 0; i < 3; i++)
            {
                Vector2 trailOffset = Projectile.velocity * (i * 0.25f);
                Vector2 drawPos = (Projectile.Center - trailOffset) - Main.screenPosition;

                // Fire sprites ignore tile lighting conditions and emit their own heat color maps
                Color drawColor = new Color(255, 180, 50, 0) * opacity;

                Main.EntitySpriteDraw(
                    texture, 
                    drawPos, 
                    sourceRectangle, 
                    drawColor, 
                    rotation, 
                    drawOrigin, 
                    Projectile.scale * (1f - i * 0.1f), 
                    SpriteEffects.None, 
                    0
                );
            }

            return false; // Tells tModLoader to skip rendering the blank placeholder PNG file
        }

        public override void OnHitNPC(NPC target, NPC.HitInfo hit, int damageDone)
        {
            target.AddBuff(BuffID.OnFire, 180);
        }
    }
}
