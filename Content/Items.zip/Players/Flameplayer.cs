using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using Terraria.DataStructures;
using Growrarria.Content.Projectiles;
using Growrarria.Content.Items;

namespace Growrarria.Content.Players
{
    // This ModPlayer hooks into the local player's update loop to:
    //   1. Track whether the FlameEye accessory is currently equipped.
    //   2. Poll the Q key every tick while equipped.
    //   3. Spawn FlameBreath projectiles at the cursor while Q is held.
    //   4. Render a glowing tracking particle over the character's eye layer.
    public class FlameEyePlayer : ModPlayer
    {
        // Set to true each frame by UpdateAccessory if the FlameEye is equipped.
        // Reset to false at the start of each frame by ResetEffects so it naturally
        // turns off the moment the accessory is unequipped or swapped out.
        public bool hasFlameEye = false;

        // Cooldown counter between projectile bursts (in ticks).
        private int flameCooldown = 0;

        // How many ticks between each burst. 4 ticks ≈ 15 bursts/second (3 projectiles
        // each), giving a dense cone without flooding NPC immune frames.
        private const int FlameInterval = 4;

        public override void ResetEffects()
        {
            // Called at the start of every frame before accessories are re-applied.
            // Resetting here means hasFlameEye is only true when the item is worn.
            hasFlameEye = false;
        }

        // FIX: Spawns the pure-particle visual glow precisely on the player's face profile
        // FIX: Replaced global Player selectors with local context structures and corrected the sprite offset fields
        // FIX: Swapped out the invalid drawInfo parameters to look directly at the native Player fields
        // FIX: Removed the visibility toggle array entirely to clear the compiler error instantly
        public override void ModifyDrawInfo(ref PlayerDrawSet drawInfo)
        {
            if (hasFlameEye) 
            {
                // Core baseline head tracking tracking
                Vector2 headCenter = Player.MountedCenter + new Vector2(0f, Player.gfxOffY) + new Vector2(0f, -12f);
                
                // --- FIX: Dynamic Pixel Tuning Alignment ---
                // Lowered from 2.5f to 1.5f to move it slightly left/back towards the skull center
                float offsetX = 1.5f * Player.direction; 

                // Check if the player is in an active walking/running animation frame sequence
                // Frame 0 is standard idle. If it's greater than 0, they are walking, running, or swinging
                if (Player.bodyFrame.Y > 0)
                {
                    // Pull the glow back by an extra pixel so it stays locked during fast movement animations
                    offsetX -= 1.0f * Player.direction;
                }

                // Final corrected vector position
                Vector2 eyePosition = headCenter + new Vector2(offsetX, -4f);

                // Spawns standard tracking embers
                if (Main.rand.NextBool(4)) 
                {
                    int d = Dust.NewDust(
                        eyePosition, 0, 0, 
                        DustID.Torch, 
                        Player.velocity.X * 0.2f, 
                        Player.velocity.Y * 0.2f - 0.3f, 
                        100, default, Main.rand.NextFloat(0.7f, 1.1f)
                    );
                    Main.dust[d].noGravity = true; 
                }

                // Core flash ignition spark
                if (Main.rand.NextBool(12))
                {
                    int d = Dust.NewDust(
                        eyePosition, 0, 0, 
                        DustID.OrangeTorch, 
                        0f, 0f, 
                        150, default, 0.4f
                    );
                    Main.dust[d].noGravity = true;
                }

                // Emits a glowing light bubble centered around the face layer
                Lighting.AddLight(eyePosition, 0.7f, 0.3f, 0.08f);
            }
        }


        public override void PostUpdate()
        {
            if (!hasFlameEye)
            {
                flameCooldown = 0;
                return;
            }

            // Only run on the owning client — prevents every connected player from
            // independently spawning projectiles for this player in multiplayer.
            if (Player.whoAmI != Main.myPlayer)
                return;

            if (flameCooldown > 0)
            {
                flameCooldown--;
                return;
            }

            // Poll Q key directly from keyboard state.
            if (!Keyboard.GetState().IsKeyDown(Keys.Q))
                return;

            flameCooldown = FlameInterval;

            // Direction from player center to cursor.
            Vector2 toMouse = Main.MouseWorld - Player.Center;
            if (toMouse == Vector2.Zero)
                toMouse = -Vector2.UnitY;
            toMouse.Normalize();

            // 3 projectiles per burst with a small random spread for a cone shape.
            for (int i = 0; i < 3; i++)
            {
                float spreadAngle = Main.rand.NextFloat(
                    -MathHelper.ToRadians(12f),
                     MathHelper.ToRadians(12f));

                Vector2 spreadVelocity = toMouse.RotatedBy(spreadAngle) * Main.rand.NextFloat(8f, 14f);

                // Spawn from just in front of the player so flames originate at the face.
                Vector2 spawnPos = Player.Center + toMouse * 20f;
                Projectile.NewProjectile(
                    Player.GetSource_FromThis(),
                    spawnPos,
                    spreadVelocity,
                    ModContent.ProjectileType<FlameBreath>(),
                    30,
                    2f,
                    Player.whoAmI
                );
            }

            // Face the cursor while firing.
            Player.ChangeDir(Main.MouseWorld.X > Player.Center.X ? 1 : -1);
        }
    }
}
